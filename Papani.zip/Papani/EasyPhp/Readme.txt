== EasyPHP 1.8.1modgsi
== www.easyphp.org
== www.reseaucerta.org pour la version "modgsi"
== apache 1.3.34 - php 4.3.11 - mysql 5.0.18 - phpmyadmin 2.7.0-pl2


Avant d'installer une nouvelle version
--------------------------------------
- sauvegardez vos donn�es (scripts, bases, fichiers de configuration, logs ...)
- si les services sont install�s : les d�sinstaller (administrateurs seulement)
- arr�tez apache et mysql puis fermez easyphp
- d�sinstallez la version pr�c�dente (supprimez � la main les fichiers r�siduels)
- installez la nouvelle version


Avertissements
--------------
EasyPHP installe et configure automatiquement un environnement de travail. EasyPHP est donc un outil de d�veloppement et non pas de production. Si vous souhaitez faire de la production tournez vous vers une solution LAMP (Linux Apache MySQL  PHP). Pour des raisons de stabilit� des logiciels (portage exp�rimental), de s�curit� du syst�me et des donn�es, une plateforme Windows� est � proscrire.


MySQL
-----
Attention MySQL est d�j� install�. il est inutile de le reinstaller.



Configuration PHP
-----------------
* register_globals = Off [s�curit�, performance]
Depuis la version 4.2.0 de PHP, la valeur par d�faut de register_global est � Off dans le php.ini. Dor�navant une variable envoy�e par un formulaire (m�thode POST) n'est plus r�cup�r�e avec $variable mais avec $_POST["variable"]. Toutes les variables globales sont concern�es (POST, GET, cookies, environnement et autres variables serveur : $_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_REQUEST, $_SESSION). Ceci peut n�cessiter la r��criture partielle de certains scripts.
Rq : il est vivement conseill� d'utiliser cette configuration qui est celle adopt�e par d�faut depuis PHP 4.2.0 et de coder vos scripts en cons�quence. Cependant si vous souhaitez utiliser d'anciens scripts sans avoir � les r��crire, vous avez toujours la possibilit� de remettre dans le fichier php.ini register_global � On.

* error_reporting = E_ALL [codage propre]
Les erreurs de codage et les avertissements (warning) sont pris en compte. Cette configuration est plus restrictive mais n�cessaire pour un codage propre. Il est donc possible que certains scripts g�n�rent des avertissements qui n'apparaissaient pas auparavant. Dans ce cas, il s'agira essentiellement de notifications. Si ces notifications sont dues � un codage intentionnel vous pouvez les supprimer en rempla�ant dans le fichier php.ini la ligne "error_reporting = E_ALL" par "error_reporting = E_ALL & ~E_NOTICE".


Installation
------------
L'installation se fait dor�navant � l'int�rieur d'un seul r�pertoire, m�me pour les fichiers de configuration My.ini et php.ini.
Cela permet de faire cohabiter cette version avec des versions ulterieurs d'EasyPHP.
De plus, cela permet d'installer EasyPHP sur une cl� USB.


Environnement
-------------
- nouvelle version du manager


Conseils
--------
Si vous rencontrer des probl�mes avec certaines dll du r�pertoire php, tentez de les placer dans le r�pertoire syst�me.


Support
-------
Exemples, forum et FAQ sur le site d'EasyPHP : www.easyphp.org


Auteurs
-------
Laurent Abbal (laurent@abbal.com)
Emmanuel Faivre (manu@manucorp.com)
Thierry Murail (thierry@easyphp.org)


Version "modgsi"
----------------
Olivier Korn (olivier.korn@reseaucerta.org)