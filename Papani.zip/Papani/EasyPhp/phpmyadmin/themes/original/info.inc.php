<?php
/* $Id: info.inc.php,v 2.3 2005/09/05 11:49:08 lem9 Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 2;
$theme_generation = 2;
?>
