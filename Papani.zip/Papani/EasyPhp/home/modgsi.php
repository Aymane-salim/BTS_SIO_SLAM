<?php
# [MODGSI] Modifications du r�seau CERTA <http://www.reseaucerta.org/>
# 2006/01/17 - Olivier Korn <olivier.korn@reseaucerta.org> :
#   Ajout : module de configuration initiale pour la MODGSI.

// Fonction permettant de g�n�rer des mots de passe.
function gen_passe($longueur) {
	$passe = '';
	$caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#/!@{}0123456789';
	$maxpos = strlen($caracteres) - 1;
	
	for ($i = 0 ; $i < $longueur ; $i++) {
		$passe .= substr($caracteres, rand(0, $maxpos), 1);
		// NB : plus besoin de "srand" depuis PHP v4.2.0.
	}
	return $passe;
}

// Construction de l'URL vers la page d'administration (/home/).
// NB : on suppose que le protocole utilis� est HTTP et non pas HTTPS.
if ($_SERVER['SERVER_PORT'] != 80) {
	$adm_url = 'http://' . $_SERVER['HTTP_HOST'] . ':';
	$adm_url .= $_SERVER['SERVER_PORT'] . '/home/';
} else {
	$adm_url = 'http://' . $_SERVER['HTTP_HOST'] . '/home/';
}

// Toujours interdire l'acc�s direct au script modgsi.php.
if ($_SERVER['PHP_SELF'] != '/index.php' && $_SERVER['PHP_SELF'] != '/home/index.php') {
	header($_SERVER['SERVER_PROTOCOL'] . ' 301 Moved permanently');
	header('Location: ' . $adm_url);
	echo '<p><strong>L\'acc�s direct � cette page est interdit.</strong> ';
	echo 'Merci de passer par <a href="' . $adm_url . '">la page ';
	echo 'd\'administration</a>.</p>';
	exit;
}

// Le script modgsi.php ne doit �tre ex�cut� que si le mot de passe de
// l'administrateur MySQL n'a pas encore �t� d�fini.
if (($my_cnx = @mysql_connect('localhost', 'root', '')) !== FALSE) {
	if ($_SERVER['PHP_SELF'] == '/index.php') {
		// Rediriger temporairement le web local vers la page d'administration.
		header($_SERVER['SERVER_PROTOCOL'] . ' 302 Moved temporarily');
		header('Location: ' . $adm_url);
		echo '<p>Merci de <a href="' . $adm_url . '">configurer la MODGSI</a> ';
		echo 'avant de poursuivre</p>';
	} else {
		// Ici, $_SERVER['PHP_SELF'] vaut forc�ment "/home/index.php" (� cause
		// du 2�me bloc "if" du script). On est donc au bon endroit.
		
		// Remplacer la page d'administration "normale" par la page de
		// configuration MODGSI :
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[EasyPHP] - Configuration MODGSI</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body>

<div align="center">
<table width="400" cellspacing="0" cellpadding="0" border="0" align="center">
<tr>
<td>
<a href="index.php"><img src="images_easyphp/titre_easyphp_modgsi.gif" width="387" height="116" border="0"></a>
</td>
</tr>
<tr>
</table>
</div>



<div align="center">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tr> 
<td class="text1">
<?php if (empty($_POST['passe'])): ?>
Avant de pouvoir utiliser EasyPHP <em>modgsi</em>, merci de bien vouloir
configurer le compte d'administrateur MySQL en utilisant le formulaire propos�
ci-dessous.
<?php else: ?>
Merci d'avoir configur� EasyPHP <em>modgsi</em>. Vous pouvez commencer �
travailler avec Apache, PHP, MySQL et phpMyAdmin d�s maintenant.
<?php endif; ?>
</td>
</tr>
</table>
</div>

<br><br>

<div align="center">
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">

<?php if (!empty($_POST['passe'])): /* D�but phpMyAdmin */ ?>
<tr> 
<td nowrap><img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/phpmyadmin.gif" width="128" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"></td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td bgcolor="#666666"><?php bouton_fleche('Autoconfiguration', "index.php", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>

</td></tr>
<tr><td>&nbsp;</td>

<td class="text1">
<?php
	$chemin_fic_config = realpath(dirname(__FILE__) . '/../phpmyadmin/config.inc.php');
	$contenu_fic_config = file($chemin_fic_config);
	$blowfish_secret = gen_passe(46);
	$controlpass = gen_passe(rand(12,14));
	
	$chercher = array(
		'/^\s*(\$cfg\[\'blowfish_secret\'\]\s*=\s*\').*(\';.*)$/',
		'/^\s*(\$cfg\[\'Servers\'\]\[\$i\]\[\'controlpass\'\]\s*=\s*\').*(\';.*)$/'
	);
	$remplacer = array(
		'${1}' . $blowfish_secret . '${2}',
		'${1}' . $controlpass . '${2}'
	);
	$contenu_fic_config = preg_replace($chercher, $remplacer, $contenu_fic_config);
	
	$req_sql = 'GRANT SELECT, INSERT, UPDATE, DELETE ON phpmyadmin.* TO \'phpmyadmin\'@\'localhost\' IDENTIFIED BY \'' . $controlpass . '\'';
	$my_res = @mysql_query($req_sql, $my_cnx);
	if ($my_res === FALSE) {
		$msg = 'Erreur inattendue : impossible de cr�er le <i>controluser</i> de phpMyAdmin (' . mysql_error() . ') !<br><br>';
	} else {
		$msg = '';
	}
	
	$fd = @fopen($chemin_fic_config, 'w');
	if ($fd === FALSE) {
		$msg .= 'Erreur inattendue : ne pouvant pas modifier le fichier ';
		$msg .= 'config.inc.php de phpMyAdmin, les fonctions avanc�es ';
		$msg .= 'propos�es par cet outil ne sont pas disponibles ';
		$msg .= 'imm�diatement.';
	} else {
		foreach($contenu_fic_config as $ligne) {
			fwrite($fd, $ligne);
		}
		fclose($fd);
		$msg .= 'Les extensions de phpMyAdmin ont bien �t� configur�es. ';
		$msg .= 'Toutes les fonctions avanc�es propos�es par cet outil sont ';
		$msg .= 'd�sormais disponibles.';
	}
	
	echo $msg;
?>
<br><br>
</td>

</tr>
<?php endif; /* Fin phpMyAdmin */ ?>


<tr> 
<td nowrap>
<img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/mysql.gif" width="68" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26">
</td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td bgcolor="#666666"><?php bouton_fleche('Configuration', "", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>

</td>
</tr>

<tr>
<td>&nbsp;</td>

<td class="text1">

<?php if (empty($_POST['passe'])): /* D�but MySQL (non configur�) */ ?>

<form method="post" action="index.php">
Les serveurs Apache et MySQL �tant accessibles depuis tous les postes du r�seau,
il est n�cessaire de prot�ger le compte d'administrateur (nomm� <i>root</i>)
du serveur MySQL � l'aide d'un mot de passe.<br><br>
Il est recommand� de choisir un mot de passe suffisamment complexe pour qu'il ne
puisse pas �tre devin� par les autres utilisateurs du r�seau.
<br><br>
<img src="images_easyphp/num_1.gif" width="14" height="18" align="absbottom">&nbsp;choisir un mot de passe pour <i>root</i> (� retenir&nbsp;!)<br>
<img src="images_easyphp/num_2.gif" width="14" height="18" align="absbottom">&nbsp;saisir le mot de passe ci-dessous<br>
<img src="images_easyphp/1x1.gif" width="14" height="18" align="absbottom"><input type="text" name="passe" size="50"><br>
<img src="images_easyphp/num_3.gif" width="14" height="18" align="absbottom">&nbsp;valider ("OK")<br>
<img src="images_easyphp/num_4.gif" width="14" height="18" align="absbottom">&nbsp;EasyPHP <i>modgsi</i> sera configur� automatiquement.
<br><br>
<input type="image" src="images_easyphp/bouton_valider.gif" border="0" width="38" height="18" alt="OK">
<br><br>
</form>

<?php else: /* D�but MySQL (configur�) */
	$passeok = mysql_real_escape_string($_POST['passe'], $my_cnx);
	if ($passeok === FALSE) {
		$msg = 'Erreur inattendue : impossible d\'utiliser mysql_real_escape_string !';
	} else {
		$req_sql = 'SET PASSWORD = PASSWORD(\'' . $passeok . '\')';
		$my_res = @mysql_query($req_sql, $my_cnx);
		if ($my_res === FALSE) {
			$msg = 'Erreur inattendue : impossible de modifier le mot de passe de root (' . mysql_error() . ') !';
		} else {
			$msg = 'Le mot de passe choisi a �t� attribu� � l\'administrateur MySQL <i>root</i>.';
		}
	}
	
	echo $msg;
?>


<br><br>
<span class="text2">Vous pouvez maintenant acc�der au <i>web</i> local ou aux
pages d'administration d'EasyPHP.</span>
<br><br>

<?php endif; /* Fin MySQL */ ?>

</td>
</tr>

<?php if (!empty($_POST['passe'])): /* D�but EasyPHP */ ?>
<tr> 
<td nowrap><img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/easyphp.gif" width="86" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"></td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td><?php bouton('Web_local', "/", "") ?></td>
<td><img src="images_easyphp/1x1.gif" width="20" height="26"></td>
<td><?php bouton('Administration', "/home/", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>
</td>

<tr>
<td></td>
<td class="text1">

Pour acc�der � tout moment au <i>web</i> local ou � la page d'administration,
il suffit de cliquer avec le bouton droit de la souris sur l'ic�ne d'EasyPHP
(dans la barre de notification, pr�s de l'horloge) et de choisir l'entr�e de
menu correspondante.
<br><br>

</td>
</tr>
<?php endif; /* Fin EasyPHP */ ?>


</table>
</div>

</body>
</html>
<?php
	// Fin du remplacement
	}

	mysql_close($my_cnx); // Fermer la connexion MySQL et...
	exit; // ... Ne pas revenir au script appelant.
}

// Sinon, revenir au script appelant...
?>