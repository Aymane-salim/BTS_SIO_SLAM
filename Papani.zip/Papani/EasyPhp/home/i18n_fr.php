<?php
$accueilMsg = "Une <b>introduction</b> � EasyPHP, une section \"<b>support</b>\" et une <b>faq PHP</b> sont pr�sentes sur la page d'%s";
$ajouter = "ajouter_un_+alias+";
$addAlias = "ajouter";
$modifier = "modifier_+datadir+";
$gestion_bdd = "gestion_bdd"; //le caractere _ remplace l'espace
$datadir = "+datadir+";
$phpinfo = "phpinfo";
$licence = "licence";
$nbExtensions = "Vous avez %s extensions charg&eacute;es";
$afficherExtensions = "afficher";
$ext = "extensions";
$bouton_alias = "+alias+"; //le caractere + remplace le guillemet

//== licence php ==
?>