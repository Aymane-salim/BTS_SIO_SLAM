<?php
//== index.php ==
$accueilMsg = "An EasyPHP <b>introduction</b>, a \"<b>support</b>\" section and a <b>PHP faq</b> are available on %s page";
$ajouter = "ajouter_un_+alias+";
$addAlias = "add";
$modifier = "modifier_+datadir+";
$gestion_bdd = "manage_database"; //le caractere _ remplace l'espace
$datadir = "+datadir+";
$phpinfo = "phpinfo";
$licence = "licence";
$nbExtensions = "You have %s extensions loaded";
$afficherExtensions = "display";
$ext = "extensions";
$bouton_alias = "+alias+"; //le caractere + remplace le guillemet

//== licence php ==
?>