<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[EasyPHP] - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>
<body>
<?php
$titre = "licence_pear";
function bouton($word){
	$lenght=strlen($word);
	$start = 0;
	print("<table border='0' cellspacing='0' cellpadding='0'>");
	print("<tr><td><img src='images_easyphp/bouton_gauche.gif' width='4' height='26'></td><td background='images_easyphp/bouton_fond.gif'>"); 
	while($start<$lenght){
		$car=substr($word,$start,1);
		print("<img src='images_easyphp/lettre_".$car.".gif' border='0'>");
		$start++;
	} 
	print("</td><td><img src='images_easyphp/bouton_droit.gif' width='4' height='26'></td></tr></table>");
}
?>

<table width="400" cellspacing="0" cellpadding="0" border="0" align="center">
  <tr>
<td>
<a href="index.php"><img src="images_easyphp/titre_easyphp_admin.gif" width="387" height="116" border="0"></a>
</td>
</tr>
<tr>
<td>
<?php bouton($titre) ?>
</td>
</tr>
<tr>
<td class="text2"> Les informations ci-dessous sont donn�es � titre indicatif. Consultez le site officiel (<a href="http://pear.php.net/" target="_blank" class="text1">PEAR</a>) pour toute information l�gale. </td>
</tr>
</table>

<br><br>

<table border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="text1">
<pre>
What licenses are allowed in PEAR/PECL?
Answer written by Jan Lehnardt, Tomas V.V. Cox and Rasmus Lerdorf. 

To make it short: Any Open Source/Free Software License. See the
OSI Approved Licenses (http://www.opensource.org/licenses/index.html)
for a summary of Open Source licenses and FSF Approved Licenses
(http://www.gnu.org/licenses/license-list.html). Pick one that
appears on both lists.
It does not need to be a GPL-compatible license from the FSF list.
Here are a subset of the licenses that are on both lists: Apache License,
Artistic license, BSD license, Common Public License, GPL,
IBM Public License, Intel Open Source License, Jabber Open Source License,
LGPL, MIT license, Mozilla Public License, PHP License, Python license,
Python Software Foundation License, QPL, Sleepycat License,
Sun Industry Standards Source License (SISSL), Sun Public License,
W3C license, zlib/libpng license, Zope Public license. 

The recomended licenses are PHP (http://de.php.net/license/2_02.txt),
LGPL (http://www.fsf.org/licenses/lgpl.txt) and BSD
(http://www.opensource.org/licenses/bsd-license.html)style. 

Note that for PECL extensions that are linked into PHP, the license must
be compatible with the PHP license. That means you can not GPL a PECL
extension or you would be violating the GPL. Note also that if you write
an extension that links against a GPL'ed library you will be violating
the GPL. If you need to link against a GPL'ed library, get permission
from the author of the library. 

To set the license of you PEAR/PECL package, put it in the head of all
source code files of your package and also the type of it inside the
&lt;license> tag of your package description file (package.xml). 
</pre>
</td>
</tr>
</table>

</body>
</html>
