<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[EasyPHP] - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>
<body>
<?php
$titre = "presentation_php";
function bouton($word){
	$lenght=strlen($word);
	$start = 0;
	print("<table border='0' cellspacing='0' cellpadding='0'>");
	print("<tr><td><img src='images_easyphp/bouton_gauche.gif' width='4' height='26'></td><td background='images_easyphp/bouton_fond.gif'>"); 
	while($start<$lenght){
		$car=substr($word,$start,1);
		print("<img src='images_easyphp/lettre_".$car.".gif' border='0'>");
		$start++;
	} 
	print("</td><td><img src='images_easyphp/bouton_droit.gif' width='4' height='26'></td></tr></table>");
}
?>

<table width="400" cellspacing="0" cellpadding="0" border="0" align="center">
  <tr>
<td>
<a href="index.php"><img src="images_easyphp/titre_easyphp_admin.gif" width="387" height="116" border="0"></a>
</td>
</tr>
<tr>
<td>
<?php bouton($titre) ?>
</td>
</tr>
</table>

<br><br>

<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
<td class="text1">
<pre>
What is PHP?

PHP is a widely-used general-purpose scripting language that is
especially suited for Web development and can be embedded into HTML.
If you are new to PHP and want to get some idea of how it works,
try the introductory tutorial (http://www.php.net/tut.php).
After that, check out the online manual (http://www.php.net/docs.php),
and the example archive sites and some of the other resources
available in the links section (http://www.php.net/links.php). 
</pre>
</td>
</tr>
<tr>
<td class="text2"><div align="right">extrait - source : <a href="http://www.php.net" target="_blank" class="text2">php</a></div></td>
</tr>
</table>

</body>
</html>
