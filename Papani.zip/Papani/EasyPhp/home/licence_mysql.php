<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[EasyPHP] - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>
<body>
<?php
$titre = "licence_mysql";
function bouton($word){
	$lenght=strlen($word);
	$start = 0;
	print("<table border='0' cellspacing='0' cellpadding='0'>");
	print("<tr><td><img src='images_easyphp/bouton_gauche.gif' width='4' height='26'></td><td background='images_easyphp/bouton_fond.gif'>"); 
	while($start<$lenght){
		$car=substr($word,$start,1);
		print("<img src='images_easyphp/lettre_".$car.".gif' border='0'>");
		$start++;
	} 
	print("</td><td><img src='images_easyphp/bouton_droit.gif' width='4' height='26'></td></tr></table>");
}
?>

<table width="400" cellspacing="0" cellpadding="0" border="0" align="center">
<tr>
<td>
<a href="index.php"><img src="images_easyphp/titre_easyphp_admin.gif" width="387" height="116" border="0"></a>
</td>
</tr>
<tr>
<td>
<?php bouton($titre) ?>
</td>
</tr>
<tr>
<td class="text2">Les informations ci-dessous sont donn�es � titre indicatif. Consultez le site officiel (<a href="http://www.mysql.com" target="_blank" class="text1">MySQL</a>) pour toute information l�gale. </td>
</tr>
</table>

<br><br>

<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
<td class="text1">
<pre>
MySQL Licenses
--------------

The `MySQL' software is released under the `GNU General Public License'
(`GPL'), which probably is the best known `Open Source' license.  The
formal terms of the `GPL' license can be found at
`http://www.gnu.org/licenses/'.  See also
`http://www.gnu.org/licenses/gpl-faq.html' and
`http://www.gnu.org/philosophy/enforcing-gpl.html'.

Since the `MySQL' software is released under the `GPL', it may often be
used for free, but for certain uses you may want or need to buy
commercial licenses from `MySQL AB' at `https://order.mysql.com/'.  See
`http://www.mysql.com/products/licensing.html' for more information.

Older versions of `MySQL' (3.22 and earlier) are subject to a more
strict license (`http://www.mysql.com/products/mypl.html').  See the
documentation of the specific version for information.

Please note that the use of the `MySQL' software under commercial
license, `GPL', or the old `MySQL' license does not automatically give
you the right to use `MySQL AB' trademarks.  *Note MySQL AB Logos and
Trademarks::.

Using the MySQL Software Under a Commercial License
...................................................

The `GPL' license is contagious in the sense that when a program is
linked to a `GPL' program all the source code for all the parts of the
resulting product must also be released under the `GPL'.  Otherwise you
break the license terms and forfeit your right to use the `GPL' program
altogether and also risk damages.

You need a commercial license:

   * When you link a program with any `GPL' code from the `MySQL'
     software and don't want the resulting product to be `GPL', maybe
     because you want to build a commercial product or keep the added
     non-`GPL' code closed source for other reasons. When purchasing
     commercial licenses, you are not using the `MySQL' software under
     `GPL' even though it's the same code.

   * When you distribute a non-`GPL' application that *only* works with
     the `MySQL' software and ship it with the `MySQL' software. This
     type of solution is actually considered to be linking even if it's
     done over a network.

   * When you distribute copies of the `MySQL' software without
     providing the source code as required under the `GPL' license.

   * When you want to support the further development of the `MySQL'
     database even if you don't formally need a commercial license.
     Purchasing support directly from `MySQL AB' is another good way of
     contributing to the development of the `MySQL' software, with
     immediate advantages for you.  *Note Support::.

If you require a license, you will need one for each installation of the
`MySQL' software. This covers any number of CPUs on a machine, and there
is no artificial limit on the number of clients that connect to the
server in any way.

For commercial licenses, please visit our website at
`http://www.mysql.com/products/licensing.html'.  For support contracts,
see `http://www.mysql.com/support/'.  If you have special needs or you
have restricted access to the Internet, please contact our sales staff
at &lt;sales@mysql.com&gt;.

Using the MySQL Software for Free Under GPL
...........................................

You can use the `MySQL' software for free under the `GPL' if you adhere
to the conditions of the `GPL'.  For more complete coverage of the
common questions about the `GPL' see the generic FAQ from the Free
Software Foundation at `http://www.gnu.org/licenses/gpl-faq.html'.
Some common cases:

   * When you distribute both your own application as well as the
     `MySQL' source code under the `GPL' with your product.

   * When you distribute the `MySQL' source code bundled with other
     programs that are not linked to or dependent on the `MySQL' system
     for their functionality even if you sell the distribution
     commercially.  This is called mere aggregation in the `GPL'
     license.

   * If you are not distributing *any* part of the `MySQL' system, you
     can use it for free.

   * When you are an Internet Service Provider (ISP), offering web
     hosting with `MySQL' servers for your customers.  However, we do
     encourage people to use ISPs that have MySQL support, as this will
     give them the confidence that if they have some problem with the
     `MySQL' installation, their ISP will in fact have the resources to
     solve the problem for them.  Note that even if an ISP does not
     have a commercial license for `MySQL Server', they should at least
     give their customers read access to the source of the `MySQL'
     installation so that the customers can verify that it is patched
     correctly.

   * When you use the `MySQL' Database Software in conjunction with a
     web server, you do not need a commercial license (so long as it is
     not a product you distribute). This is true even if you run a
     commercial web server that uses `MySQL Server', because you are not
     distributing any part of the `MySQL' system. However, in this case
     we would like you to purchase `MySQL' support because the `MySQL'
     software is helping your enterprise.

If your use of `MySQL' database software does not require a commercial
license, we encourage you to purchase support from `MySQL AB' anyway.
This way you contribute toward `MySQL' development and also gain
immediate advantages for yourself. *Note Support::.

If you use the `MySQL' database software in a commercial context such
that you profit by its use, we ask that you further the development of
the `MySQL' software by purchasing some level of support.  We feel that
if the `MySQL' database helps your business, it is reasonable to ask
that you help `MySQL AB'.  (Otherwise, if you ask us support questions,
you are not only using for free something into which we've put a lot a
work, you're asking us to provide free support, too.)
</pre>
</td>
</tr>
</table>

</body>
</html>
