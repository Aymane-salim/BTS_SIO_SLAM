<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="style.css"/>
		<title>Le Gourmet</title>
	</head>
	
	<body>
		<div class="container" align="center">
			<header>
				<div class="header" align="center">
					<a href="index.html"><img class="imagelogo" src="Images\logo.jpg"/></a><br>
					<ul class="navigationheader">
						<li><a href="index.html">ACCUEIL</a></li>
						<li><a href="Cartes.php">CARTE</a></li>
						<li><a href="Photos.php">PHOTOS</a></li>
						<li><a href="AccesReservation.html">ACCES/RESERVATION</a></li>
					</ul>
				</div>
			</header>
		
			

<?php
// connexion au serveur et A la base de donn? Gourmet

require('connexion.php');

// variable requAate projection de tous les champs de la table Produits

$req1="SELECT Produits.*,Categories.NCat,Appartenir.Prix
FROM Produits,Appartenir,Categories 
WHERE Appartenir.Ref=Produits.Ref
AND Categories.Ncat=Appartenir.Ncat
AND Produits.Ref BETWEEN 01 AND 21
AND Categories.NCat = '1' ";

$req2="SELECT Produits.*,Categories.NCat,Appartenir.Prix
FROM Produits,Appartenir,Categories 
WHERE Appartenir.Ref=Produits.Ref
AND Categories.Ncat=Appartenir.Ncat
AND Produits.Ref BETWEEN 01 AND 21
AND Categories.NCat = '2' ";

$req3="SELECT Produits.*,Categories.NCat,Appartenir.Prix
FROM Produits,Appartenir,Categories 
WHERE Appartenir.Ref=Produits.Ref
AND Categories.Ncat=Appartenir.Ncat
AND Produits.Ref BETWEEN 01 AND 21
AND Categories.NCat = '3' ";

$req4="SELECT Produits.Photos,Produits.Designation
FROM Produits 
WHERE Produits.Photos IN ('4FR.jpg','MEX.jpg','SAV.jpg')";

$req5="SELECT *
FROM Produits,Appartenir 
WHERE Appartenir.Ref=Produits.Ref
AND Produits.Ref BETWEEN 22 AND 27";

$req6="SELECT *
FROM Produits,Appartenir 
WHERE Appartenir.Ref=Produits.Ref
AND Produits.Ref IN (28,29)";

// variable execution de la requAate et stockage de la reponse dans la variable $sql

$sql1=mysql_query($req1) or die ('Erreur requette SQL');
$sql2=mysql_query($req2) or die ('Erreur requette SQL');
$sql3=mysql_query($req3) or die ('Erreur requette SQL');
$sql4=mysql_query($req4) or die ('Erreur requette SQL');
$sql5=mysql_query($req5) or die ('Erreur requette SQL');
$sql6=mysql_query($req6) or die ('Erreur requette SQL');

// crACation d'un tableau et affichage des noms des colonnes

echo "<table class='pizzas' width= 10%>";
echo"<h1>Pizzas</h1><tr><th></th>
<th>Junior</th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql1))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center><td>$Designation</td>";
echo "<td>$Prix €</td></tr>";
  
}
echo "</table>";

// crACation d'un tableau et affichage des noms des colonnes

echo "<table class='pizzas' width= 10%>";
echo"<tr>
<th>Sénior</th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql2))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center>";
echo "<td>$Prix €</td></tr>";
  
}
echo "</table>";

// crACation d'un tableau et affichage des noms des colonnes

echo "<table class='pizzas' width= 10%>";
echo"<tr>
<th>Méga</th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql3))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center>";
echo "<td>$Prix €</td></tr>";
  
}
echo "</table>";

// crACation d'un tableau et affichage des noms des colonnes

echo "<table class='pizzas'>";
echo"<tr>
<th width=250px></th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql4))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center>";
echo "<td><br><br><br><img src='Images/$Photos' title='$Designation'></td></tr>";
  
}
echo "</table>";

// crACation d'un tableau et affichage des noms des colonnes

echo "<table width= 80%>";
echo"<h1>Desserts</h1><tr><th></th>
<th width=30%>Prix</th>
<th width=250px></th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql5))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center><td>$Designation</td>";
echo "<td>$Prix €</td>";
echo "<td><img src='Images/$Photos'></td></tr>";
  
}
echo "</table>";

// crACation d'un tableau et affichage des noms des colonnes

echo "<table width= 80%>";
echo"<h1>Boissons</h1><tr><th></th>
<th width=30%>Prix</th>
<th width=250px></th></tr>";

// boucle tantque lecture ligne par ligne du tableau des donnACes stockACes dans la variable $rs  tant qu'il ya des lignes A lire

while($donnees=mysql_fetch_array($sql6))
{
extract($donnees);
 
// affichage des variables
 
echo "<tr align=center><td>$Designation </td>";
echo "<td>$Prix €</td>";
echo "<td><img src='Images/$Photos'></td></tr>";
  
}
echo "</table>";
?>

			<footer>
				<div class="footer">
					<a class="copyright" href="index.html" target="_blank">Copyright by AYMANE © 2019 Le Gourmet</a>
					<a class="facebook" href="https://www.facebook.com/Cr%C3%AAperie-le-gourmet-1515374308773939/timeline?ref=page_internal" target="_blank"> <img src="Images\logofacebook.png"/></a>
					<a href="Admin/index.html" target="_blank">Administration</a>
				</div>
			</footer>
		</div>
	</body>
	
</html>