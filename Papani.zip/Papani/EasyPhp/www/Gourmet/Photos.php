<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="style.css"/>
		<title>Le Gourmet</title>
	</head>
	
	<body>
		<div class="container" align="center">
			<header>
				<div class="header" align="center">
					<a href="index.html"><img class="imagelogo" src="Images\logo.jpg"/></a><br>
					<ul class="navigationheader">
						<li><a href="index.html">ACCUEIL</a></li>
						<li><a href="Cartes.php">CARTE</a></li>
						<li><a href="Photos.php">PHOTOS</a></li>
						<li><a href="AccesReservation.html">ACCES/RESERVATION</a></li>
					</ul>
				</div>
			</header>
		
			<div class="slider" align="center">
				<ul>
					<li><img src="Images\Photos1.jpg"></li>
					<li><img src="Images\Photos2.jpg"></li>
					<li><img src="Images\Photos3.jpg"></li>
					<li><img src="Images\Photos4.jpg"></li>
					<li><img src="Images\Photos5.jpg"></li>
					<li><img src="Images\Photos6.jpg"></li>
					<li><img src="Images\Photos7.jpg"></li>
					<li><img src="Images\Photos8.jpg"></li>
				</ul>
			</div>
		
			<footer>
				<div class="footer">
					<a class="copyright" href="index.html" target="_blank">Copyright by AYMANE © 2019 Le Gourmet</a>
					<a class="facebook" href="https://www.facebook.com/Cr%C3%AAperie-le-gourmet-1515374308773939/timeline?ref=page_internal" target="_blank"> <img src="Images\logofacebook.png"/></a>
					<a href="Admin/index.html" target="_blank">Administration</a>
				</div>
			</footer>
		</div>
	</body>
	
</html>