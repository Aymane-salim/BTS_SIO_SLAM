<?php

//connexion au serveur et à la BDD Gourmet

require('connexion.php');

// Si le formulaire à été validé

if(isset($_POST['submit'])) 
{
	// Si les champs ne sont pas vides ...
	if(!empty($_POST['Nom']) && !empty($_POST['Prenom']) &&  !empty($_POST['Adressemail']) && !empty($_POST['Telephone']) && !empty($_POST['Message'])
	   && !empty($_POST['dateReserv']))
	{
		//récupération des variables
		$Nom=$_POST["Nom"];
		$Prenom=$_POST["Prenom"];
		$Adressemail=$_POST["Adressemail"];
		$Telephone=$_POST["Telephone"];
		$Message=$_POST["Message"];
		$dateReserv=$_POST["dateReserv"];
		
		// Insertion de la réservation dans la BDD		
		mysql_query	("INSERT INTO Reservation VALUES('','$Nom','$Prenom','$Adressemail','$Telephone','$Message',NOW(),'$dateReserv')") or die('<div align="center">Erreur SQL !</div>'); 
		
		// Message ajout confirmé
		echo 'Reservation ajoutee avec succes ! <br>';
		echo 'Reservation faite le : <br>' .date("D/M/Y - h:i:s");
		echo '<br> Reservation pour le : ' .date($dateReserv);
	}		
	// Sinon , si les champs ne sont pas vides
	else
	{
?>

<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="style.css"/>
		<title>Le Gourmet</title>
	</head>
	<body>
		<div class="container" align="center">
			<header>
				<div class="header" align="center">
					<a href="index.html"><img class="imagelogo" src="Images\logo.jpg"/></a><br>
					<ul class="navigationheader">
						<li><a href="index.html">ACCUEIL</a></li>
						<li><a href="Cartes.php">CARTE</a></li>
						<li><a href="Photos.php">PHOTOS</a></li>
						<li><a href="AccesReservation.php">ACCES/RESERVATION</a></li>
					</ul>
				</div>
			</header>
		
			<div align="center">
				<h1>Accès</h1>
				Restaurant Le Gourmet</br>
				92 Avenue Aristide Briand</br>
				93190 Livry-Gargan</br>
				Téléphone : 09.83.71.32.06</br>
				Portable : 06.34.59.67.71</br>
				</br>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2622.008732379878!2d2.5266495156763793!3d48.91522587929306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6139520ca7e95%3A0x435ab8fe2977b3a9!2s92+Avenue+Aristide+Briand%2C+93190+Livry-Gargan%2C+France!5e0!3m2!1sfr!2sus!4v1458574651200" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<h1>Infos pratiques</h1>
				<h2>Services</h2>
				Restaurant privatisable (50 personnes max.)</br>
				Ouvert le dimanche, Accès Wifi</br>
				<h2>Moyens de paiement</h2>
				Carte Bleue, Carte Mastercard, Carte Visa, Titres et chèques pour les restaurants
			</div>
			
			
			
			
			
					<div align="center">
				<h1>Réservation</h1>
				<p>Pour toute réservation veuillez remplir le formulaire ci-dessous afin que nous puissions vous contactez !</p>
				<form class="reservation" align="center" action="reservation.php" method="POST">
	
			<div align="center">
				<h1>Réservation</h1>
				<p>Pour toute réservation veuillez remplir le formulaire ci-dessous afin que nous puissions vous contactez !</p>
				<form class="reservation" align="center" action="reservation.php" method="POST">
					<div>
						<input class="nom" type="text" placeholder="* Nom" name="Nom">
						<input class="prenom" type="text" placeholder="* Prénom" name="Prenom">
					</div>
					<div>
						<input class="adressemail" type="text" placeholder="* E-mail" name="Adressemail">
						<input class="telephone" type="text" placeholder="* Téléphone" name="Telephone">
					</div>
					<div>
						<textarea class="msg" placeholder="* Laissez votre message" maxlength="600" rows='8' name='Message'></textarea>
						<p class="champobligatoire">Veuillez remplir tous les champs *</p>
					</div>
										<div>
						<input class="datereserv" type="date" name="dateReserv"/>
					</div>
					<div>
						<input class="submit" type='submit' value='Envoyer' name="submit"/>
					</div>
				</form>
			</div>
			
			<footer>
				<div class="footer">
					<a class="copyright" href="index.html" target="_blank">Copyright by AYMANE © 2019 Le Gourmet</a>
					<a class="facebook" href="https://www.facebook.com/Cr%C3%AAperie-le-gourmet-1515374308773939/timeline?ref=page_internal" target="_blank"> <img src="Images\logofacebook.png"/></a>
					<a href="Admin/index.html" target="_blank">Administration</a>
				</div>
			</footer>
		</div>
	</body>
	
</html>

<?php

	}

}

?>