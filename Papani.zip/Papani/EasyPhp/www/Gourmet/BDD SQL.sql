-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeudi 05 Mai 2016 à 18:36
-- Version du serveur: 5.0.18
-- Version de PHP: 4.3.11
-- 
-- Base de données: `Gourmet`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `Appartenir`
-- 

CREATE TABLE `Appartenir` (
  `Ref` int(3) NOT NULL auto_increment,
  `NCat` varchar(2) NOT NULL,
  `Prix` double NOT NULL,
  PRIMARY KEY  (`Ref`,`NCat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

-- 
-- Contenu de la table `Appartenir`
-- 

INSERT INTO `Appartenir` VALUES (1, '1', 8);
INSERT INTO `Appartenir` VALUES (1, '2', 13);
INSERT INTO `Appartenir` VALUES (1, '3', 18);
INSERT INTO `Appartenir` VALUES (2, '1', 8);
INSERT INTO `Appartenir` VALUES (2, '2', 13);
INSERT INTO `Appartenir` VALUES (2, '3', 18);
INSERT INTO `Appartenir` VALUES (3, '1', 8);
INSERT INTO `Appartenir` VALUES (3, '2', 12);
INSERT INTO `Appartenir` VALUES (3, '3', 18);
INSERT INTO `Appartenir` VALUES (4, '1', 8);
INSERT INTO `Appartenir` VALUES (4, '2', 12);
INSERT INTO `Appartenir` VALUES (4, '3', 18);
INSERT INTO `Appartenir` VALUES (5, '1', 8);
INSERT INTO `Appartenir` VALUES (5, '2', 13);
INSERT INTO `Appartenir` VALUES (5, '3', 18);
INSERT INTO `Appartenir` VALUES (6, '1', 9);
INSERT INTO `Appartenir` VALUES (6, '2', 14);
INSERT INTO `Appartenir` VALUES (6, '3', 19);
INSERT INTO `Appartenir` VALUES (7, '1', 8);
INSERT INTO `Appartenir` VALUES (7, '2', 13);
INSERT INTO `Appartenir` VALUES (7, '3', 18);
INSERT INTO `Appartenir` VALUES (8, '1', 7);
INSERT INTO `Appartenir` VALUES (8, '2', 9);
INSERT INTO `Appartenir` VALUES (8, '3', 13);
INSERT INTO `Appartenir` VALUES (9, '1', 8);
INSERT INTO `Appartenir` VALUES (9, '2', 13);
INSERT INTO `Appartenir` VALUES (9, '3', 18);
INSERT INTO `Appartenir` VALUES (10, '1', 8);
INSERT INTO `Appartenir` VALUES (10, '2', 12);
INSERT INTO `Appartenir` VALUES (10, '3', 18);
INSERT INTO `Appartenir` VALUES (11, '1', 8);
INSERT INTO `Appartenir` VALUES (11, '2', 13);
INSERT INTO `Appartenir` VALUES (11, '3', 18);
INSERT INTO `Appartenir` VALUES (12, '1', 8);
INSERT INTO `Appartenir` VALUES (12, '2', 12);
INSERT INTO `Appartenir` VALUES (12, '3', 18);
INSERT INTO `Appartenir` VALUES (13, '1', 8);
INSERT INTO `Appartenir` VALUES (13, '2', 13);
INSERT INTO `Appartenir` VALUES (13, '3', 18);
INSERT INTO `Appartenir` VALUES (14, '1', 8);
INSERT INTO `Appartenir` VALUES (14, '2', 13);
INSERT INTO `Appartenir` VALUES (14, '3', 18);
INSERT INTO `Appartenir` VALUES (15, '1', 8);
INSERT INTO `Appartenir` VALUES (15, '2', 13);
INSERT INTO `Appartenir` VALUES (15, '3', 18);
INSERT INTO `Appartenir` VALUES (16, '1', 8);
INSERT INTO `Appartenir` VALUES (16, '2', 12);
INSERT INTO `Appartenir` VALUES (16, '3', 18);
INSERT INTO `Appartenir` VALUES (17, '1', 9);
INSERT INTO `Appartenir` VALUES (17, '2', 14);
INSERT INTO `Appartenir` VALUES (17, '3', 19);
INSERT INTO `Appartenir` VALUES (18, '1', 9);
INSERT INTO `Appartenir` VALUES (18, '2', 14);
INSERT INTO `Appartenir` VALUES (18, '3', 19);
INSERT INTO `Appartenir` VALUES (19, '1', 9);
INSERT INTO `Appartenir` VALUES (19, '2', 14);
INSERT INTO `Appartenir` VALUES (19, '3', 19);
INSERT INTO `Appartenir` VALUES (20, '1', 8);
INSERT INTO `Appartenir` VALUES (20, '2', 13);
INSERT INTO `Appartenir` VALUES (20, '3', 18);
INSERT INTO `Appartenir` VALUES (21, '1', 8);
INSERT INTO `Appartenir` VALUES (21, '2', 12);
INSERT INTO `Appartenir` VALUES (21, '3', 18);
INSERT INTO `Appartenir` VALUES (22, '4', 5);
INSERT INTO `Appartenir` VALUES (23, '4', 2);
INSERT INTO `Appartenir` VALUES (24, '4', 3);
INSERT INTO `Appartenir` VALUES (25, '4', 3);
INSERT INTO `Appartenir` VALUES (26, '4', 4);
INSERT INTO `Appartenir` VALUES (27, '4', 6);
INSERT INTO `Appartenir` VALUES (28, '5', 1);
INSERT INTO `Appartenir` VALUES (29, '5', 3);

-- --------------------------------------------------------

-- 
-- Structure de la table `Categories`
-- 

CREATE TABLE `Categories` (
  `NCat` varchar(2) NOT NULL,
  `Libelle` varchar(10) NOT NULL,
  PRIMARY KEY  (`NCat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `Categories`
-- 

INSERT INTO `Categories` VALUES ('1', 'junior');
INSERT INTO `Categories` VALUES ('2', 'senior');
INSERT INTO `Categories` VALUES ('3', 'mega');
INSERT INTO `Categories` VALUES ('4', 'dessert');
INSERT INTO `Categories` VALUES ('5', 'boisson');

-- --------------------------------------------------------

-- 
-- Structure de la table `Produits`
-- 

CREATE TABLE `Produits` (
  `Ref` int(3) NOT NULL auto_increment,
  `Designation` varchar(30) NOT NULL,
  `Photos` varchar(10) NOT NULL,
  PRIMARY KEY  (`Ref`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

-- 
-- Contenu de la table `Produits`
-- 

INSERT INTO `Produits` VALUES (1, '4 Fromages', '4FR.jpg');
INSERT INTO `Produits` VALUES (2, '4 Saisons', '4SA.jpg');
INSERT INTO `Produits` VALUES (3, 'Calzone', 'CAL.jpg');
INSERT INTO `Produits` VALUES (4, 'Campione', 'CAM.jpg');
INSERT INTO `Produits` VALUES (5, 'Chorizo', 'CHO.jpg');
INSERT INTO `Produits` VALUES (6, 'Fruits de mer', 'FRU.jpg');
INSERT INTO `Produits` VALUES (7, 'Kebab', 'KEB.jpg');
INSERT INTO `Produits` VALUES (8, 'Marguerita', 'MAR.jpg');
INSERT INTO `Produits` VALUES (9, 'Mexicaine', 'MEX.jpg');
INSERT INTO `Produits` VALUES (10, 'Napolitaine', 'NAP.jpg');
INSERT INTO `Produits` VALUES (11, 'Neptune', 'NEP.jpg');
INSERT INTO `Produits` VALUES (12, 'Orientale', 'ORI.jpg');
INSERT INTO `Produits` VALUES (13, 'Paysanne', 'PAY.jpg');
INSERT INTO `Produits` VALUES (14, 'Pizza du CHEF', 'PIZ.jpg');
INSERT INTO `Produits` VALUES (15, 'Provencale', 'PRO.jpg');
INSERT INTO `Produits` VALUES (16, 'Regina', 'REG.jpg');
INSERT INTO `Produits` VALUES (17, 'Saint-Jacques', 'SAI.jpg');
INSERT INTO `Produits` VALUES (18, 'Saumon', 'SAU.jpg');
INSERT INTO `Produits` VALUES (19, 'Savoyarde', 'SAV.jpg');
INSERT INTO `Produits` VALUES (20, 'Texas', 'TEX.jpg');
INSERT INTO `Produits` VALUES (21, 'Vegetarienne', 'VEG.jpg');
INSERT INTO `Produits` VALUES (22, 'Salade de fruits', 'SAL.jpg');
INSERT INTO `Produits` VALUES (23, 'Tarte aux pommes', 'TAR.jpg');
INSERT INTO `Produits` VALUES (24, 'Crepe Nutella', 'CR1.jpg');
INSERT INTO `Produits` VALUES (25, 'Crepe Nutella Banane', 'CR2.jpg');
INSERT INTO `Produits` VALUES (26, 'Petit Haagen-Dazs', 'HA1.jpg');
INSERT INTO `Produits` VALUES (27, 'Grand Haagen-Dazs', 'HA2.jpg');
INSERT INTO `Produits` VALUES (28, 'Boissons 33cl', '33CL.jpg');
INSERT INTO `Produits` VALUES (29, 'Boissons 150cl', '150CL.jpg');

-- --------------------------------------------------------

-- 
-- Structure de la table `Reservation`
-- 

CREATE TABLE `Reservation` (
  `Num` int(11) NOT NULL auto_increment,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Adressemail` varchar(20) NOT NULL,
  `Telephone` varchar(20) NOT NULL,
  `Message` varchar(600) NOT NULL,
  PRIMARY KEY  (`Num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Contenu de la table `Reservation`
-- 