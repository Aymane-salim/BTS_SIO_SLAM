<?php
//Connexion au serveur MySQL
try{

$connect = mysql_connect('localhost','root','f5mqz') or die ('Impossible de se connecter à MySQL');

//Connexion à la base de données

$db = mysql_select_db('Gourmet',$connect)

}catch(Exception e) 
{
die ('Impossible de se connecter à la base de données');
}
?>