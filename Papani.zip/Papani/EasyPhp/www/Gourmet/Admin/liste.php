<html>

	<head>
	<meta charset="iso-8859-1"/>
		<link rel="stylesheet" href="style.css"/>
		<title>Liste des Reservations</title>
	</head>

<body>


<?php
//  connection au serveur et à la base de données ucpa
	require('../connexion.php');

// variable requête projection de tous les champs de la table enfants
	$req="SELECT * FROM Reservation";

// variable execution de la requête et stoquage de la reponse dans la variable $sql
	$sql=mysql_query($req) or die ('erreur requête SQL');

//  création d'un tableau et affichage des noms des colonnes
	?>
	<table width= "65%" border=3>
		<i><b><font size="+2">Reservation de clients:</font></b></i>
		<tr> 
			<th>Nom</th>
			<th>Prenom</th>
			<th>Adresse Email</th>
			<th>Telephone</th>
			<th>Message</th>
			<th>Reservation pour le :</th>
		</tr>
		
		<?php	  
			// boucle tantque lecture ligne par ligne du tableau des données stockées dans la variable $rs  tant qu'il ya des lignes à lire
			while($donnees=mysql_fetch_array($sql))
			{
				//extract($donnees);
				//affichage des variables
		?>				
				<tr>
					<td><?php echo $donnees['Nom']; ?></td>
					<td><?php echo $donnees['Prenom']; ?></td>
					<td><?php echo $donnees['Adressemail']; ?></td>
					<td><?php echo $donnees['Telephone']; ?></td>
					<td><?php echo $donnees['Message']; ?></td>
					<td><?php echo $donnees['dateReserv']; ?></td>
				</tr>
		<?php
			}
		?>
	</table>

</body>
</html>
