<?php

//connexion au serveur et à la BDD Gourmet

require('connexion.php');
	
	if(isset($_POST['submit'])) 
{
	// Si les champs ne sont pas vides ...
	if(!empty($_POST['Designation']) &&  !empty($_POST['Prix']) &&  !empty($_POST['NCat']))
	{
		//récupération des variables
        $Designation=$_POST['Designation'];
		$Prix=$_POST['Prix'];
        $NCat=$_POST['NCat'];
        $Photos=$_POST['Photos'];
	
		
		// Insertion de la réservation dans la BDD		
		mysql_query("INSERT INTO Produits VALUES('','$Designation', '$Photos')") or die('<div align="center">Erreur SQL</div>');
		mysql_query("INSERT INTO Appartenir VALUES('','$NCat', '$Prix')") or die('<div align="center">Erreur SQL</div>');

		// Message ajout confirmé
		echo 'Produit ajouté avec succès !';
	}
	// Sinon , si les champs ne sont pas vides
	else
	{
?>

<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="/Gourmet/style.css"/>
		<title>Le Gourmet</title>
	</head>
	
	<body>
		<div class="container" align="center">
			<header>
				<div align="center">
					<a href="\Gourmet\index.html"><img class="imagelogo" src="\Gourmet\Images\logo.jpg"/></a>
					<div class="retour" align="left">
						<a href="\Gourmet\index.html"><h2>< Retour à l'Accueil</h2></a>
					</div>
					<h1>Administration</h1>
				</div>
			</header>

			<div align="center">
				<h1>Ajouter un Produit</h1>
				<form class="ajoutdeproduit" align="center" action="AjoutProduit.php" method="POST">
					<div>
						<input class="designation" type="text" placeholder="* Désignation" name="Designation"/>
					</div>
					<div>
						<input class="prix" type="text" placeholder="* Prix" name="Prix"/>
					</div>
					<div>
						* Numéro de catégorie : <select class="ncat" name="NCat">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</div>
					<div>
						* Photos : <input class="photos" type="file" placeholder="Laissez votre message" name='Photos'/>
						<p class="champobligatoire">Veuillez remplir tous les champs *</p>
					</div>
					<div>
						<input class="submit" type="submit" value="Ajouter" name="submit"/><input class="reset" type="reset" value="Annuler" name="reset"/>
					</div>
				</form>
			</div>
		</div>
	</body>
	
</html>

<?php

	}

}

?>