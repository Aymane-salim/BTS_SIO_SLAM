<?php
//== index.php ==
$ajouter = "crear_un_+alias+";
$addAlias = "a�adir";
$modifier = "modifier_+datadir+";
$gestion_bdd = "gestion_bbdd"; //le caractere _ remplace l'espace
$datadir = "+datadir+";
$phpinfo = "phpinfo";
$licence = "licencia";
$nbExtensions = "Tienes %s extensiones cargadas";
$afficherExtensions = "ver";
$ext = "extensiones";
$bouton_alias = "+alias+"; //le caractere + remplace le guillemet

//== licence php ==
?>
