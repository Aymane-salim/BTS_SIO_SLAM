<?php
$version_apache = "1.3.34";
$version_php = "4.3.11";
$version_mysql = "5.0.18";
$version_phpmyadmin = "2.7.0_pl2";
?>