<?php
# [MODGSI] Modifications du r�seau CERTA <http://www.reseaucerta.org/>
# 2006/01/17 - Olivier Korn <olivier.korn@reseaucerta.org> :
#   Ajout : il faut configurer la MODGSI avant de naviguer sur le web local.
include('modgsi.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[EasyPHP] - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body>

<?php
$langFile = "";
include("i18n_en.php");	// une premiere fois pour la langue par d�faut

$browser_languages = explode(",", getenv("HTTP_ACCEPT_LANGUAGE"));
$nb_browser_languages = sizeof($browser_languages);
$browser_lang = "";	// ne pas initialiser

for ($niI = 0; $langFile=="" && $niI < $nb_browser_languages; $niI++)
{
	$lg = explode("-", $browser_languages[$niI]);
	switch ($lg[0])
	{
	case "fr" : $langFile = "i18n_fr.php"; break;
	case "es" : $langFile = "i18n_sp.php"; break;
	case "en" : $langFile = "i18n_en.php"; break;	
	}
}
if ($langFile=="")
	$langFile = "i18n_en.php";

@include($langFile);	// Langue selectionn�"
include("ver_strings.php");

if (isset($HTTP_GET_VARS)){
	while(list($name, $value) = each($HTTP_GET_VARS)){
		$$name = $value;
	}
}
	
if (!isset($to)) $to = '';
if (!isset($_POST['to'])) $_POST['to'] = '';
if (!isset($exts)) $exts = '';
if (!isset($exts)) $do = '';
if (!isset($exts)) $directory = '';

function bouton($word, $lien, $cible){
	$lenght=strlen($word);
	$start = 0;
	print("<table border='0' cellspacing='0' cellpadding='0'>");
	print("<tr><td><img src='images_easyphp/bouton_gauche.gif' width='4' height='26'></td><td background='images_easyphp/bouton_fond.gif'>");
	print("<a href=$lien $cible>");  
	while($start<$lenght){
		$car=substr($word,$start,1);
		print("<img src='images_easyphp/lettre_".$car.".gif' border='0'>");
		$start++;
	}
	print("</a>");  
	print("</td><td><img src='images_easyphp/bouton_droit.gif' width='4' height='26'></td></tr></table>");
}

function bouton_fleche($word,$lien, $cible){
	$lenght=strlen($word);
	$start = 0;
	print("<table border='0' cellspacing='0' cellpadding='0'>");
	print("<tr><td><img src='images_easyphp/bouton_fleche_gauche.gif' width='4' height='26'></td><td background='images_easyphp/bouton_fleche_fond.gif'>");
	print("<a href=$lien $cible>");   
	while($start<$lenght){
		$car=substr($word,$start,1);
		print("<img src='images_easyphp/lettre_".$car.".gif' border='0'>");
		$start++;
	}
	print("</a>");   
	print("</td><td><img src='images_easyphp/bouton_fleche_droit.gif' width='4' height='26'></td></tr></table>");
}

function num_version($num){
	$lenght=strlen($num);
	$start = 0;
	while($start<$lenght){
		$chiffre=substr($num,$start,1);
		# [MODGSI] Modifications du r�seau CERTA <http://www.reseaucerta.org/>
		# 2006/01/06 - Olivier Korn <olivier.korn@reseaucerta.org> :
		#   Modification : tenir compte des num�ros de version qui contiennent des lettres.
		if (file_exists('images_easyphp/chiffre_'.$chiffre.'.gif')) {
			print("<img src='images_easyphp/chiffre_".$chiffre.".gif' border='0'>");
		} else {
			print("<img src='images_easyphp/lettre_".$chiffre.".gif' border='0'>");
		}
		$start++;
	}
}
?>
<div align="center">
<table width="400" cellspacing="0" cellpadding="0" border="0" align="center">
<tr>
<td>
<a href="index.php"><img src="images_easyphp/titre_easyphp_admin.gif" width="387" height="116" border="0"></a>
</td>
</tr>
<tr>
</table>
</div>



<div align="center">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tr> 
<td class="text1">
<?php printf($accueilMsg, "<a href=\"accueil.html\"><img src=\"images_easyphp/accueil.gif\" width=\"60\" height=\"12\" border=\"0\" align=\"absbottom\"></a>"); ?>
</td>
</tr>
</table>
</div>

<br><br>

<div align="center">
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
<tr> 
<td width="200" nowrap> <img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/apache.gif" width="74" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26">
<?php num_version($version_apache) ?>
</td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td bgcolor="#666666"><?php bouton_fleche($bouton_alias, "index.php", "") ?></td>
<td><img src="images_easyphp/1x1.gif" width="20" height="26"></td>
<td><?php bouton($licence, "licence_apache.php", "") ?></td>
</tr>
</table>
</td>
</tr>
<tr> 
<td>&nbsp;</td>
<td class="text1"> 

<?php
//===================================================================================================
function read_alias(){
	global $alias, $directory, $httpd, $httpd_1, $n, $httpd_2, $httpd_3, $nb_alias, $source;
	$source = "../conf_files/httpd.conf";
	$fp = fopen($source, "r");
	$httpd = "";
	while (!feof($fp)){
		$conf = fgets($fp, 4096);
		$httpd = $httpd.$conf;
	}
	fclose($fp);
	$exp1 = explode("#alias",$httpd);
	$httpd_1 = $exp1[0];
	$httpd_2 = $exp1[1];
	$httpd_3 = $exp1[2];
	$exp2 = explode("Alias",$httpd_2);
	
	$n = 1;
	$nb_alias = count($exp2)-1;
	while($n<=$nb_alias){
		$exp3 = explode("<Directory",$exp2[$n]);
		$alias[$n] = "Alias".$exp3[0];
		$directory[$n] = "<Directory".$exp3[1];
		$n++;
	}
}

function list_alias(){
	global $inc, $alias, $nb_alias, $exp4, $exp5, $alias_link, $nb_alias, $alias_name;
	$inc = 1;
	while($inc <= $nb_alias){
		$exp4 = explode("\"",$alias[$inc]);
		$exp5 = explode("/",$exp4[1]);
		$alias_link = $exp4[3];
		$alias_name = $exp5[1];
		$alias_link = str_replace("/","\\", $alias_link);
		print("<table border='0' cellspacing='0' cellpadding='0'>");
		print("<tr>");
		print("<td class='text1' valign='top'>");
		print("<img src='images_easyphp/1x1.gif' width='10' height='16' align='absbottom'><img src='images_easyphp/dossier_alias.gif' width='23' height='16' align='absbottom'>&nbsp;");
		print("</td>");
		print("<td class='text1'>");
		print("<a href='../$alias_name/' target='_blank' class='text1'>$alias_name</a>&nbsp;&nbsp;&nbsp;&nbsp;[&nbsp;$alias_link&nbsp;]&nbsp;&nbsp;&nbsp;&nbsp;");
		print("[&nbsp;<a href='index.php?to=del_alias&num_alias=$inc' class=text2>supprimer</a>&nbsp;]<br>");
		print("</td>");
		print("</tr>");
		print("</table>");
		$inc++;
	}
	print("<img src='images_easyphp/1x1.gif' width='10' height='16' align='absbottom'><img src='images_easyphp/dossier_alias.gif' width='23' height='16' align='absbottom'>&nbsp;");
	print("...&nbsp;&nbsp;&nbsp;&nbsp;");
	printf("[&nbsp;<a href='index.php?to=add_alias_1' class=text2>%s</a>&nbsp;]<br><br>", $GLOBALS['addAlias']);
}		

if ($to == "add_alias_1"){
?>
<form method="post" action="index.php">
Les alias permettent de placer vos d&eacute;veloppements dans un ou plusieurs r&eacute;pertoires ind&eacute;pendamment du r&eacute;pertoire racine d'apache (www).
<br><br>
<img src="images_easyphp/num_1.gif" width="14" height="18" align="absbottom">&nbsp;cr&eacute;er votre r&eacute;pertoire (ex.: C:\weblocal\sites\site1) <br>
<img src="images_easyphp/num_2.gif" width="14" height="18" align="absbottom">&nbsp;saisir un nom pour l'alias (ex.: site1)<br>
<img src="images_easyphp/1x1.gif" width="14" height="18" align="absbottom"><input type="text" name="alias_name" size="50"><br>
<img src="images_easyphp/num_3.gif" width="14" height="18" align="absbottom">&nbsp;saisir le chemin du r&eacute;pertoire cr&eacute;&eacute; (ex.: C:\weblocal\sites\site1)<br>
<img src="images_easyphp/1x1.gif" width="14" height="18" align="absbottom"><input type="text" name="alias_link" size="50"><br>
<img src="images_easyphp/num_4.gif" width="14" height="18" align="absbottom">&nbsp;param&egrave;tres par d&eacute;faut du r&eacute;pertoire<br>
<img src="images_easyphp/1x1.gif" width="14" height="18" align="absbottom"><textarea name="dir" cols="45" rows="4" wrap="virtual">Options Indexes FollowSymLinks Includes
AllowOverride All
#Order allow,deny
Allow from all
</textarea>
<br>
<img src="images_easyphp/num_5.gif" width="14" height="18" align="absbottom">&nbsp;valider ("OK")<br>
<img src="images_easyphp/num_6.gif" width="14" height="18" align="absbottom">&nbsp;cliquer sur red&eacute;marrer et attendre que apache et mysql repassent au vert dans le statut.
<br><br>
<input type="hidden" name="to" value="add_alias_2">
<input type="image" src="images_easyphp/bouton_valider.gif" border="0" width="38" height="18" alt="envoyer">
<br><br>
rq : il existe une copie de secours du fichier httpd.conf dans le r�pertoire "safe" : httpd-safe.conf
</form>
	         
<?php
}elseif ($_POST['to'] == "add_alias_2"){
		if ($_POST['alias_name'] == "" | $_POST['alias_link'] == "" | !is_dir($_POST['alias_link'])){
			if ($_POST['alias_name'] == ""){print("&nbsp;&nbsp;<img src='images_easyphp/exclam.gif' width='10' height='18' align='absbottom'>&nbsp;le champ 2 est vide.<br>");}
			if ($_POST['alias_link'] == ""){print("&nbsp;&nbsp;<img src='images_easyphp/exclam.gif' width='10' height='18' align='absbottom'>&nbsp;le champ 3 est vide.<br>");}
			if ($_POST['alias_link'] != "" & !is_dir($_POST['alias_link'])){print("&nbsp;&nbsp;<img src='images_easyphp/exclam.gif' width='10' height='18' align='absbottom'>&nbsp;le r&eacute;pertoire correspondant au chemin que vous avez saisi n'existe pas.<br>");}
			print("&nbsp;&nbsp;[&nbsp;<a href=\"javascript:history.back()\" class=\"text2\">retour</a>&nbsp;]<br><br>");
			clearstatcache();
		}else{
			read_alias();
			$dir = ereg_replace("\r\n","\n",$_POST['dir']);
			//$alias_link = stripslashes($_POST['alias_link']);
			$alias_link = str_replace("\\","/", $_POST['alias_link']);
			
			if (substr($alias_link, -1) == "/"){$alias_link = substr($alias_link,0,strlen($alias_link)-1);}
			$new_alias = "Alias \"/";
			$new_alias .= $_POST['alias_name'];
			$new_alias .= "\" \"";
			$new_alias .= $alias_link;
			$new_alias .= "/\"\n";
			$new_alias .= "<Directory \"$alias_link\">\n".$dir."</Directory>\n\n";
			$conf = $httpd_1."#alias".$httpd_2.$new_alias."#alias\n".$httpd_3;
			$fp2 = fopen($source, "w");
			fputs($fp2,$conf);
			fclose($fp2);
			read_alias();
			list_alias();
		}
}elseif ($to == "del_alias"){
		read_alias();
		$conf_del_alias = $httpd_1."#alias\n";
		$x = 1;
		while($x<=$nb_alias){
			if ($x != $num_alias){$conf_del_alias = $conf_del_alias.$alias[$x].$directory[$x];}
			$x++;
		}
		$conf_del_alias = $conf_del_alias."#alias\n".$httpd_3;
		$fp3 = fopen($source, "w");
		fputs($fp3,$conf_del_alias);
		fclose($fp3);
		read_alias();
		list_alias();
}else{
		read_alias();
		list_alias();
}
//===========================================================================================
?>

</td>
</tr>


<tr> 
<td nowrap><img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/php.gif" width="38" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><?php num_version($version_php) ?></td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td bgcolor="#666666"><?php bouton_fleche($ext, "index.php", "") ?></td>
<td><img src="images_easyphp/1x1.gif" width="20" height="26"></td>
<td><?php bouton($phpinfo, "phpinfo.php", "") ?></td>
<td><?php bouton($licence, "licence_php.php", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>
</td>

<tr>
<td></td>
<td class="text1">

<?php
//===========================================================================================
$extensions = @get_loaded_extensions();
printf("&nbsp;&nbsp;&nbsp;".$nbExtensions."&nbsp;", count($extensions));
printf("[&nbsp;<a href='index.php?to=ext' class=text2>%s</a>&nbsp;]<br>", $afficherExtensions);
if ($to=="ext"){
	@sort($extensions);
	foreach($extensions as $extension){
		print("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='/images_easyphp/carre_jaune.gif' width='10' height='10' align='absbottom'>&nbsp;$extension&nbsp;&nbsp;[&nbsp;<a href='index.php?to=ext&exts=$extension' class=text2>fonctions</a>&nbsp;]<br>");
		if ($extension==$exts){
			$functions = @get_extension_funcs($exts);
			@sort($functions);
			foreach($functions as $function){print("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#149;&nbsp;$function<br>");}
		}
	}
}
print("<br>");
//===========================================================================================
?>

</td>
</tr>
<tr> 
<td nowrap><img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/phpmyadmin.gif" width="128" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><?php num_version($version_phpmyadmin) ?></td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td><?php bouton($gestion_bdd, "/mysql/", "target='_blank'") ?></td>
<td><?php bouton($licence, "licence_phpmyadmin.php", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>

</td>
</tr>



<tr> 
<td nowrap>
<img src="images_easyphp/cube_rouge.gif" width="18" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><img src="images_easyphp/mysql.gif" width="68" height="26"><img src="images_easyphp/1x1.gif" width="5" height="26"><?php num_version($version_mysql) ?>
</td>
<td>

<table border="0" cellpadding="0" cellspacing="5">
<tr>
<td><?php bouton($licence, "licence_mysql.php", "") ?></td>
<td>&nbsp;</td>
</tr>
</table>

</td>
</tr>

</table>
</div>

</body>
</html>