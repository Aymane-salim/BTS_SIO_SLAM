<?php
/* Theme information */
$theme_name = 'Arctic Ocean';
$theme_version = 2;
$theme_generation = 2;
?>
